/*var nombre = "JavaScript"

function saludar{
    console.log("Hola" + nombre)
}

function saludo(){
    var nombre = "Andres"
    console.log(nombre)
}

saludo()
console.log(nombre)

function saludar(nombre){
    console.log("Hola" + nombre)
    console.log("el clima eta soleado")
}

function clima(){
    console.log("Hola Duvan, el clima esta soleado")
}*/

function pedir(nombre, año, mes, dia, fecha){
    var años = (2023-año)
    var dias = (12*años+mes)
    console.log("Hola" + nombre)
    console.log("el clima eta soleado")
    console.log("Los dias que han pasado desde tu nacimiento son" + (365*años+dia-fecha))
}











function año(año){
    console.log(año)
}

function año1(año1){
    console.log(año1)
|
    function resta(){
        console.log(año - año1)
    }
}

function resta(){
    console.log(año - año1)
}

function mes(mes){
    console.log("Su mes de nacimiento es" + mes)
}
function año(año){
    console.log("Su dia de nacimiento es" + año)
}



function notas(notas){
    console.log(notas)
}

function promedio(){
    (a,b,c,d) 
}